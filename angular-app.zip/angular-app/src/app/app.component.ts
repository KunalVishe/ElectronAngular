import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'my-app';
  inputValue: string = '';
  responseData: any;

  constructor(private http: HttpClient) {}

  handleClick() {
     this.http.post('http://localhost:3000/api/echo', { message: this.inputValue })
      .subscribe(response => {
        this.responseData = response;
      });
  }
}
