// index.js
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;


app.use(cors()); // Allow requests from other origins
app.use(express.json()); // Parse JSON body

const angularDistPath = path.join(__dirname, '../angular-app/dist/my-app/browser');

app.use(express.static(angularDistPath)); // Serve static files from Angular app

console.log('folder Path:', angularDistPath);
// POST endpoint
app.post('/api/echo', (req, res) => {
  const { message } = req.body;
  res.json({
    frontendValue: message,
    backendValue: " - from Node.js backend"
  });
});
  
app.get('/', (req, res) => {
  console.log('Serving index from:', path.join(angularDistPath, 'index.html'));
  res.sendFile(path.join(angularDistPath, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
